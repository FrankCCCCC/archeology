import java.io.*;
import java.net.*;

public class MultiThreadServer implements Runnable{
   private Socket socket;

   MultiThreadServer(Socket socket)
   {
      this.socket=socket;
   }
   public static void main(String args[])throws Exception
   {
      // Register service on port 8888
      ServerSocket server = new ServerSocket(8888);
      System.out.println("listening");
      // Infinite loop
      while(true)
      {
         // Wait and accept a connection
         Socket s = server.accept();
         System.out.println("connected");
         // Create a new Thread to handle this connection
         new Thread(new MultiThreadServer(s)).start();
      }
   }
   public void run()
   {
      try{
         // Get a communication stream associated with the socket
         DataOutputStream out= new DataOutputStream(socket.getOutputStream());
         // Send a string!
         out.writeUTF("Hi");
         // Close the connection(client) don't close the server 
         socket.close();
         out.close();
      }
      catch(Exception e){
          e.printStackTrace();
      }  
   }
}

