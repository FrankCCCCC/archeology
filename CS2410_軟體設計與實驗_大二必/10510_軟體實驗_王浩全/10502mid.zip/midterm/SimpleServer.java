// SimpleServer.java: a simple server program
import java.net.*;
import java.io.*;
public class SimpleServer {
	public static void main(String args[]) throws IOException {
		// Register service on port 8888
		ServerSocket server = new ServerSocket(8888);
		System.out.println("listening");
		// Wait and accept a connection
		Socket s=server.accept(); 
		System.out.println("connected");
		// Get a communication stream associated with the socket
		DataOutputStream out = new DataOutputStream (s.getOutputStream());
		// Send a string!
		out.writeUTF("Hi there");
		// Close the connection, but not the server socket
		out.close();
		s.close();
	}
}