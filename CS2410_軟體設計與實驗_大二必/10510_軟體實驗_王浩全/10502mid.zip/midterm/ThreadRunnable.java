import java.util.*;
import java.lang.*;
import java.io.*;
//method1 
/*class ChildThread implements Runnable
{
	public void run()
	{
		System.out.println("hi");
	}
}
class ThreadRunnable {
	public static void main(String [] args ) {
		Thread t1 = new Thread(new ChildThread());
		Thread t2 = new Thread(new ChildThread());
		t1.start();
		t2.start();
	}
}
*/
//method2
class ThreadRunnable implements Runnable{
	public static void main(String [] args ) {
		ThreadRunnable tr = new ThreadRunnable();
		Thread t1 = new Thread(tr);
		Thread t2 = new Thread(tr);
		t1.start();
		t2.start();
	}
	
	public void run()
	{
		System.out.println("hi");
	}
}