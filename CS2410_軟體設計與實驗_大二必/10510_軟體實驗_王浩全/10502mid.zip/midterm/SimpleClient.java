// SimpleClient.java: a simple client program
import java.net.*;
import java.io.*;
public class SimpleClient {
	public static void main(String args[]) throws IOException {
		// Open your connection to a server, at port 8888
		Socket s = new Socket("127.0.0.1",8888);
		// Get an input file handle from the socket and read the input
		DataInputStream in = new DataInputStream(s.getInputStream());
		String str = new String (in.readUTF());
		System.out.println(str);
		// When done, just close the connection and exit
		in.close();
		s.close();
	}
}