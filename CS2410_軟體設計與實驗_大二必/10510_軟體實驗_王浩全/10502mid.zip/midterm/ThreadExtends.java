import java.util.*;
import java.lang.*;
import java.io.*;

class ThreadExtends extends Thread {
	public static void main(String [] args ) {
		ThreadExtends t1 = new ThreadExtends();
		ThreadExtends t2 = new ThreadExtends();
		t1.start();
		t2.start();
	}
	public void run()
	{
		System.out.println("hi");
	}
}
